// sessionStorage.setItem('key', 'value');
// var value = sessionStorage.getItem('key');
// sessionStorage.removeItem('key');
// sessionStorage.clear();

// sessionStorage.setItem('user_1', 'Maxkamov1')
// sessionStorage.setItem('user_1', 'Maxkamov Moxirbek')
// sessionStorage.setItem('user_1', 'Maxkamov Moxirbek')
// sessionStorage.setItem('user_1', 'Maxkamov Moxirbek')
// sessionStorage.setItem('user_1', 'Maxkamov Moxirbek')
localStorage.setItem('user_1', 'mmmm222')
localStorage.setItem('user_2', 'teest')
localStorage.setItem('mmmm', 'teest')
let myForm = document.getElementById('myForm')
let username = document.getElementById('username')
let password = document.getElementById('password')
myForm.addEventListener('submit', function () {
    if(localStorage.getItem(username.value)==password.value){
        alert('Hush kelibsz')
    }else{
        alert("Hatolik")
    }
})